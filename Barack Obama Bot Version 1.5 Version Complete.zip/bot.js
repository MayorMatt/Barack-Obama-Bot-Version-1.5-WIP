
                let Discord;
                let Database;
                if(typeof window !== "undefined"){
                    Discord = DiscordJS;
                    Database = EasyDatabase;
                } else {
                    Discord = require("discord.js");
                    Database = require("easy-json-database");
                }
                const delay = (ms) => new Promise((resolve) => setTimeout(() => resolve(), ms));
                const s4d = {
                    Discord,
                    client: null,
                    tokenInvalid: false,
                    reply: null,
                    joiningMember: null,
                    database: new Database("./db.json"),
                    checkMessageExists() {
                        if (!s4d.client) throw new Error('You cannot perform message operations without a Discord.js client')
                        if (!s4d.client.readyTimestamp) throw new Error('You cannot perform message operations while the bot is not connected to the Discord API')
                    }
                };
                s4d.client = new s4d.Discord.Client({
                    fetchAllMembers: true
                });
                s4d.client.on('raw', async (packet) => {
                    if(['MESSAGE_REACTION_ADD', 'MESSAGE_REACTION_REMOVE'].includes(packet.t)){
                        const guild = s4d.client.guilds.cache.get(packet.d.guild_id);
                        if(!guild) return;
                        const member = guild.members.cache.get(packet.d.user_id) || guild.members.fetch(d.user_id).catch(() => {});
                        if(!member) return;
                        const channel = s4d.client.channels.cache.get(packet.d.channel_id);
                        if(!channel) return;
                        const message = channel.messages.cache.get(packet.d.message_id) || await channel.messages.fetch(packet.d.message_id).catch(() => {});
                        if(!message) return;
                        s4d.client.emit(packet.t, guild, channel, message, member, packet.d.emoji.name);
                    }
                });
                function colourRandom() {
  var num = Math.floor(Math.random() * Math.pow(2, 24));
  return '#' + ('00000' + num.toString(16)).substr(-6);
}


s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!update-notes') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Updates:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'What\'s new for version 1.5? Fixed the [Object object] glitch and added an invite link! You can now add this bot to your server!'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!invite') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Invite the bot to your server here:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'http://bit.ly/obama-bot'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!github') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Download Github here:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'https://desktop.github.com/'
                }
            }
        );
  }

});

s4d.client.login('ODI0MDgwNTA1NTIzNzk4MDg2.YFqKxw.RWrUFGwmqCWMUGbNXwHgv6oED-8').catch((e) => { s4d.tokenInvalid = true; s4d.tokenError = e; });

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!obama-almighty') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Team Obama',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'OBAMA FOREVER'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!dev-commands') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Developer Commands:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: '!replit, !devportal, !python, !github'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!obama') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Team Obama',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'Obama'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!python') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Download Python here:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'https://www.python.org/downloads/'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!shrek-the-ogerlord') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'All Star and Shrek',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'Hey now, you\'re a rockstar'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!replit') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Replit.com',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'https://replit.com/'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!beatbox') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Obama\'s 11/10 Beatboxing:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'BING BANG BOOM SKIDDY BOP BAP WOOHOO YALA BOOMITY BOY'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!trump') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Team Obama',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'Trump sucks -Obama 2021'
                }
            }
        );
  }

});

s4d.client.on('ready', async () => {
  s4d.client.user.setActivity(String('It\'s Obama Time :3 | Made By Mayor Matt'));
  s4d.client.channels.cache.find((channel) => channel.name === 'general').send(
          {
              embed: {
                  title: 'I\'m online!',
                  color: (colourRandom()),
                  image: { url: null },
                  description: 'OBAMA TIME! (Do !commands for commands, do !dev-commands for developer commands, do !update-notes for update notes)'
              }
          }
      );

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!devportal') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Discord Developer Portal',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'https://discord.com/developers/applications'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!never') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Team Obama',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'GONNA GIVE YOU UP'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!2016') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: '2016 in a nutshell:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'YEAH BOI *DAB* MNT DEW HAHAHA GET REKT'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!commands') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Commands:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: '!obama, !2016, !shrek-the-ogerlord, !obama-almighty, !credits, !kick, !ban, !penguin, !covid, !meme, !beatbox, !obumaz, !trump, !worldwar3, !never, !invite, '
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!worldwar3') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Team Obama',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'no'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!penguin') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Penguin because why not?',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'https://en.wikipedia.org/wiki/Penguin'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((((s4dmessage.content) || '').startsWith('!ban' || '')) && (s4dmessage.member).hasPermission('BAN_MEMBERS')) {
    (s4dmessage.channel).send(String('What is the reason?'));
    (s4dmessage.channel).awaitMessages((m) => m.author.id === (s4dmessage.member).id, { time: (1*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
       (s4dmessage.mentions.members.first()).send(String(('You\'ve been banned- Reason: ' + String(s4d.reply))));
      await delay(Number(2)*1000);
      (s4dmessage.mentions.members.first()).ban();
      s4dmessage.channel.send(String('They\'ve been banned now.'));

     s4d.reply = null; }).catch(async (e) => { console.error(e);  });}

});

s4d.client.on('message', async (s4dmessage) => {
  if ((((s4dmessage.content) || '').startsWith('!kick' || '')) && (s4dmessage.member).hasPermission('KICK_MEMBERS')) {
    (s4dmessage.channel).send(String('What is the reason?'));
    (s4dmessage.channel).awaitMessages((m) => m.author.id === (s4dmessage.member).id, { time: (1*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
       (s4dmessage.mentions.members.first()).send(String(('You\'ve been kicked- Reason: ' + String(s4d.reply))));
      await delay(Number(2)*1000);
      (s4dmessage.mentions.members.first()).kick();
      s4dmessage.channel.send(String('They\'ve been kicked now.'));

     s4d.reply = null; }).catch(async (e) => { console.error(e);  });}

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!credits') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Credits:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'Made by Mayor Matt | Coding help by Joe Biden | Inspired by Joe Biden\'s Welcome bot and KingKillV6\'s Welcome 2.0'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!version') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'Bot Version:',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'Barack Obama Bot, made by Mayor Matt, is version 1.1, still in development'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!meme') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'haha funny meme lol',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'https://memes.com/'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!obumaz') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: '??????',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'xbvhfiaudfniuenifaueboisdnljbsfiubeaijksd'
                }
            }
        );
  }

});

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == '!meme') {
    s4dmessage.channel.send(
            {
                embed: {
                    title: 'haha funny meme lol',
                    color: (colourRandom()),
                    image: { url: null },
                    description: 'https://memes.com/'
                }
            }
        );
  }

});

                s4d;
            